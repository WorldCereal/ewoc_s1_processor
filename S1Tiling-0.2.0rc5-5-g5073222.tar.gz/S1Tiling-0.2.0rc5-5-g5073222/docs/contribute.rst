.. _contribute:

.. index:: contributing

.. mdinclude:: ../CONTRIBUTING.md

