Issue 1 : gestion du nodata incorrecte avec le nodata = 0 à cause du thermal noise qui renvoie des valeurs à 0

Issue 2 : border mask à vérifier la version de l'IPF >= 2.9 à tester pas besoin de mask
si version inférieure, utiliser la méthode actuelle ou bien coder le pdf !
